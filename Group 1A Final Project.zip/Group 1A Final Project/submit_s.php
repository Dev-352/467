<!DOCTYPE html>
<html>
<head>
    <title>Shipping information</title>
    <h1>An email has been sent with the shipping information.</h1>
    <form action="interdone.php" method="post">
        <input type="submit" name=submit value="Return"/>
</form>
   

</head>
</html>