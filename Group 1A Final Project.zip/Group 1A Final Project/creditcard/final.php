<!DOCTYPE html>
<html>
<head>
    <title>FINAL PAGE</title>
    <h1>Thank you for buying!!!</h1>
    <p><b>Your order has been processed. An email has be sent to you.</b></P>
    <script>
        var seq = (Math.floor(Math.random() * 1000000000) + 1000000000).toString().substring(1);
        document.write("Authorization number: ", seq);
        
    </script>
   
  

</head>
</html>